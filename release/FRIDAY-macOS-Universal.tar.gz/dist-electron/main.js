"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
let mainWindow = null;
let tray = null;
const isDev = process.env.NODE_ENV === 'development' || !!process.env.VITE_DEV_SERVER_URL;
function createWindow() {
    mainWindow = new electron_1.BrowserWindow({
        width: 1280,
        height: 860,
        minWidth: 960,
        minHeight: 680,
        title: 'FRIDAY — AI Operating Assistant',
        backgroundColor: '#060913',
        // Native macOS Glassmorphism & Frameless Traffic Lights
        titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
        trafficLightPosition: { x: 18, y: 18 },
        vibrancy: process.platform === 'darwin' ? 'under-window' : undefined,
        visualEffectState: 'active',
        show: false,
        webPreferences: {
            preload: path_1.default.join(__dirname, 'preload.js'),
            nodeIntegration: false,
            contextIsolation: true,
            sandbox: false
        }
    });
    mainWindow.once('ready-to-show', () => {
        mainWindow?.show();
    });
    const devUrl = process.env.VITE_DEV_SERVER_URL || 'http://localhost:5173';
    const prodPath = path_1.default.join(__dirname, '../dist/index.html');
    if (isDev) {
        mainWindow.loadURL(devUrl);
    }
    else if (fs_1.default.existsSync(prodPath)) {
        mainWindow.loadFile(prodPath);
    }
    else {
        mainWindow.loadURL(devUrl);
    }
    mainWindow.on('closed', () => {
        mainWindow = null;
    });
}
function createTray() {
    try {
        // Create a 16x16 monochromatic menu bar icon
        const icon = electron_1.nativeImage.createEmpty();
        tray = new electron_1.Tray(icon);
        const contextMenu = electron_1.Menu.buildFromTemplate([
            { label: 'FRIDAY AI Assistant', enabled: false },
            { type: 'separator' },
            {
                label: 'Show/Hide Cockpit',
                accelerator: 'CmdOrCtrl+Shift+Space',
                click: toggleMainWindow
            },
            { type: 'separator' },
            { label: 'Quit FRIDAY', click: () => electron_1.app.quit() }
        ]);
        tray.setToolTip('FRIDAY AI Assistant');
        tray.setContextMenu(contextMenu);
        tray.on('click', toggleMainWindow);
    }
    catch (err) {
        console.warn('Tray initialization:', err);
    }
}
function toggleMainWindow() {
    if (!mainWindow) {
        createWindow();
        return;
    }
    if (mainWindow.isVisible()) {
        if (mainWindow.isFocused()) {
            mainWindow.hide();
        }
        else {
            mainWindow.focus();
        }
    }
    else {
        mainWindow.show();
        mainWindow.focus();
    }
}
electron_1.app.whenReady().then(() => {
    createWindow();
    createTray();
    // Register Global Summon Hotkey (Command + Shift + Space on Mac)
    electron_1.globalShortcut.register('CommandOrControl+Shift+Space', toggleMainWindow);
});
electron_1.app.on('will-quit', () => {
    electron_1.globalShortcut.unregisterAll();
});
electron_1.app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        electron_1.app.quit();
    }
});
electron_1.app.on('activate', () => {
    if (electron_1.BrowserWindow.getAllWindows().length === 0) {
        createWindow();
    }
    else {
        mainWindow?.show();
        mainWindow?.focus();
    }
});
